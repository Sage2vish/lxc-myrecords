export const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'LXC Health API',
    version: '1.0.0',
    description: 'Hostinger-ready Node API for MyHealthHub weather integration.',
  },
  servers: [
    {
      url: 'https://api.lexvoraconsulting.com',
      description: 'Production',
    },
    {
      url: 'http://localhost:3000',
      description: 'Local development',
    },
  ],
  tags: [
    {name: 'Health'},
    {name: 'Weather'},
  ],
  paths: {
    '/v1/health': {
      get: {
        tags: ['Health'],
        summary: 'Health check for v1',
        responses: {
          200: {
            description: 'Service is healthy',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    ok: {type: 'boolean'},
                    version: {type: 'string'},
                  },
                  required: ['ok', 'version'],
                },
              },
            },
          },
        },
      },
    },
    '/v1/weather/today': {
      get: {
        tags: ['Weather'],
        summary: 'Get current weather for v1',
        parameters: [
          {
            name: 'city',
            in: 'query',
            required: false,
            schema: {type: 'string', example: 'Dubai'},
            description: 'Optional city name. Defaults to DEFAULT_WEATHER_CITY.',
          },
        ],
        responses: {
          200: {
            description: 'Current weather summary',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    requestedCity: {type: 'string'},
                    version: {type: 'string'},
                    city: {type: 'string'},
                    region: {type: 'string'},
                    country: {type: 'string'},
                    tempC: {type: 'number'},
                    feelsLikeC: {type: 'number'},
                    condition: {type: 'string'},
                    conditionCode: {type: 'number'},
                    icon: {type: 'string'},
                    isDay: {type: 'boolean'},
                    localtime: {type: 'string'},
                    source: {type: 'string'},
                  },
                  required: ['requestedCity', 'version', 'city', 'tempC', 'condition', 'source'],
                },
              },
            },
          },
        },
      },
    },
  },
  components: {},
} as const;
